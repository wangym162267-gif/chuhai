# Dragon Monarch AI Outreach Web

## 本地运行

Windows：双击 `start_windows.bat`。  
Mac/Linux：运行 `chmod +x start_mac_linux.sh && ./start_mac_linux.sh`。  
浏览器打开：`http://127.0.0.1:8765`。

## 上传 GitHub

1. 解压这个压缩包。
2. 新建 GitHub 仓库。
3. 上传解压后的全部文件和文件夹，不要只上传 zip。
4. 不要上传 `agent_mvp/settings.json`、`.env` 或任何 API Key。
5. 第一次运行后，在网页“设置”页面填写 DeepSeek Key。

## 重要：GitHub Pages 的限制

这个网页包含 Python 后端，所以 GitHub Pages 只能展示页面，搜索客户、生成开发信等后端功能不能运行。  
如果只要代码托管，GitHub 仓库可以正常使用；如果要公开可访问的完整网址，需要把 Python 后端部署到 Render、Railway、Fly.io 等支持 Python 服务的平台。

## 数据与安全

压缩包内包含已经整理好的公开客户数据，但**不包含 API Key**。  
如果不希望客户名单出现在公开仓库，请把仓库设为 Private，或者上传前删除 `agent_mvp/data` 里的真实数据文件。  
当前 DeepSeek Key 没有放进压缩包，运行时需要在网页设置页重新填写。
