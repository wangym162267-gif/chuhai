#!/usr/bin/env python3
"""Approve selected drafts for a separate sending integration. This script does not send."""
from __future__ import annotations
import argparse, csv
from datetime import datetime, timezone
from pathlib import Path

def main() -> int:
    ap = argparse.ArgumentParser(description="Approve selected outreach drafts without sending them.")
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--lead-id", action="append", default=[])
    ap.add_argument("--reviewer", required=True)
    ap.add_argument("--allow-needs-review", action="store_true")
    args = ap.parse_args()
    with args.input.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    wanted = set(args.lead_id)
    if not wanted:
        for row in rows:
            print(row.get("lead_id") or row.get("place_id") or "", "|", row.get("venue", ""), "|", row.get("review_status", ""))
        return 0
    now = datetime.now(timezone.utc).isoformat()
    approved = 0
    for row in rows:
        if (row.get("lead_id") or row.get("place_id")) not in wanted:
            continue
        status = row.get("review_status", "")
        if status == "fail" or (status == "needs_review" and not args.allow_needs_review):
            row["human_decision"] = "rejected"
            row["send_ready"] = "no"
            continue
        row["human_decision"] = "approved"
        row["approved_by"] = args.reviewer
        row["approved_at"] = now
        row["send_ready"] = "yes"
        approved += 1
    fields = list(rows[0].keys()) if rows else []
    for field in ["human_decision", "approved_by", "approved_at", "send_ready"]:
        if field not in fields:
            fields.append(field)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)
    print(f"Approved {approved} drafts -> {args.output}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
