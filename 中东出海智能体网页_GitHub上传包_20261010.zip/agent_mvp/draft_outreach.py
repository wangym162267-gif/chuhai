#!/usr/bin/env python3
"""Generate human-reviewed outreach drafts. Never sends email."""
from __future__ import annotations
import argparse, csv, json, os, re
from pathlib import Path
from typing import Any

DRAFT_FIELDS = ["subject", "body", "subject_zh", "body_zh", "personalized_evidence", "evidence_urls", "draft_language", "draft_provider", "risk_flags", "review_status", "review_notes", "send_ready"]
FORBIDDEN = ["cure", "treat", "heal", "detox", "weight loss", "fat-burning", "lower blood sugar", "protect the stomach", "soothe the throat", "throat-soothing", "boost immunity", "prevent disease", "guaranteed revenue", "guaranteed sales", "يهدئ الحلق", "يرطب الحلق", "حماية الحلق", "علاج", "شفاء", "تخليص السموم", "حرق الدهون", "تقوية المناعة"]

def split_items(value: str) -> list[str]:
    return [x.strip() for x in re.split(r"[;,]", value or "") if x.strip()]

def review_text(subject: str, body: str, evidence_urls: list[str]) -> tuple[list[str], str, str]:
    text = (subject + "\n" + body).lower()
    flags = [term for term in FORBIDDEN if term in text]
    if not any(term in text for term in ("unsubscribe", "opt out", "إلغاء الاشتراك", "إلغاء", "لا ترسل")):
        flags.append("missing_opt_out")
    if not evidence_urls:
        flags.append("missing_evidence_url")
    if len(body) > 2200:
        flags.append("too_long")
    if len(body) < 180:
        flags.append("too_short")
    severe = any(x in flags for x in ("soothe the throat", "throat-soothing", "cure", "treat", "heal", "guaranteed revenue", "guaranteed sales", "يهدئ الحلق", "يرطب الحلق", "حماية الحلق", "علاج", "شفاء", "تخليص السموم", "حرق الدهون", "تقوية المناعة"))
    status = "fail" if severe else ("needs_review" if flags else "pass")
    notes = "; ".join(flags) if flags else "automated checks passed; human review required"
    return flags, status, notes

def template_draft(row: dict[str, Any], language: str = "en") -> dict[str, str]:
    venue = str(row.get("venue") or "your venue").strip()
    city = str(row.get("city") or "your city").strip()
    district = str(row.get("district") or "").strip()
    signals = [s for s in split_items(str(row.get("detected_signals", ""))) if s in ("cigar", "lounge", "luxury", "social", "tea", "hotel")]
    evidence = split_items(str(row.get("evidence_urls", "")))
    observation = ""
    if district and signals:
        observation = f"Your venue is located in {district} and its public pages signal a {', '.join(signals)} experience."
    elif district:
        observation = f"Your venue is located in {district}."
    elif signals:
        observation = f"Your public pages signal a {', '.join(signals)} experience."
    subject = f"A one-brick tea ritual for {venue}"
    body = (
        f"Hello {venue} team,\n\n"
        "I'm [Sender Name] from Dragon Monarch. We produce pressed whole-leaf tea for premium lounges: "
        "one brick, one pot, no scales and no tea training required.\n\n"
        f"{observation} We are selecting a small number of venues in {city} for a 14-day pilot kit. "
        "It includes five boxes, a bar card and a simple brew guide for testing a zero-sugar shared tea ritual "
        "and front-desk retail.\n\n"
        "Would you like me to send the pilot kit to your business address for the team to test? "
        "There is no purchase obligation.\n\n"
        "If you prefer not to receive messages from us, reply \"unsubscribe\" and we will remove your contact details.\n\n"
        "Best,\n[Sender Name]\nDragon Monarch\n[Company Email] - [Phone]\n"
    )
    subject_zh = f"{venue} 的一砖一壶茶饮方案"
    body_zh = (
        f"{venue} 团队您好，\n\n"
        "我们提供紧压原叶茶，适合高端 Lounge 的一砖一壶标准化出品，不需要称重，也不需要复杂培训。\n\n"
        f"{observation} 我们正在{ city }选择少量门店进行 14 天试摆，包含五盒样品、吧台卡和简单冲泡指南，用于测试无糖共享茶饮和前台上架。\n\n"
        "如无需进一步联系，请回复 unsubscribe，我们会移除您的联系方式。\n\n"
        "谢谢。"
    )
    return {"subject": subject, "body": body, "subject_zh": subject_zh, "body_zh": body_zh, "personalized_evidence": observation, "evidence_urls": ";".join(evidence)}

def ai_draft(row: dict[str, Any], model: str) -> dict[str, str]:
    try:
        from openai import OpenAI
    except Exception as exc:
        raise RuntimeError("OpenAI SDK is not installed. Run pip install -r requirements.txt") from exc
    client = OpenAI()
    schema = {
        "type": "object",
        "properties": {
            "subject": {"type": "string"},
            "body": {"type": "string"},
            "personalized_evidence": {"type": "string"},
            "risk_flags": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["subject", "body", "personalized_evidence", "risk_flags"],
        "additionalProperties": False,
    }
    evidence = {k: row.get(k, "") for k in ("venue", "city", "district", "type", "website", "menu_url", "detected_signals", "signal_counts", "website_title", "website_text_excerpt", "evidence_urls")}
    instructions = (
        "You write ethical B2B cold email drafts for a premium tea brand approaching shisha lounges, "
        "cigar lounges, hotel bars and boutique restaurants in the Gulf. Use only supplied facts. "
        "Do not invent a person, role, menu item, partnership, price, revenue result or health benefit. "
        "Never use medical or functional health claims, including soothing/relieving/protecting the throat, "
        "detox, weight loss, immunity or disease language. Written messages may describe sensory experience, "
        "unsweetened tea, one-brick-one-pot operations, social rounds, menu upgrade and front-desk retail. "
        "Include a clear unsubscribe instruction and no purchase obligation. Keep under 180 words. "
        "Mention at most two verified observations with evidence_urls. Return only the structured output."
    )
    response = client.responses.create(
        model=model,
        input=[{"role": "system", "content": instructions}, {"role": "user", "content": json.dumps(evidence, ensure_ascii=False)}],
        text={"format": {"type": "json_schema", "name": "email_draft", "strict": True, "schema": schema}},
    )
    data = json.loads(response.output_text)
    return {"subject": str(data["subject"]).strip(), "body": str(data["body"]).strip(), "personalized_evidence": str(data["personalized_evidence"]).strip(), "evidence_urls": str(row.get("evidence_urls", ""))}

def deepseek_draft(row: dict[str, Any], model: str, language: str = "en") -> dict[str, str]:
    try:
        from openai import OpenAI
    except Exception as exc:
        raise RuntimeError("OpenAI SDK is not installed. Run pip install -r requirements.txt") from exc
    api_key = os.getenv("DEEPSEEK_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("DEEPSEEK_API_KEY is not set")
    client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
    evidence = {k: row.get(k, "") for k in ("venue", "city", "district", "type", "website", "menu_url", "detected_signals", "signal_counts", "website_title", "website_text_excerpt", "evidence_urls")}
    instructions = (
        "You write ethical B2B cold email drafts for a premium tea brand approaching shisha lounges, "
        "cigar lounges, hotel bars and boutique restaurants in the Gulf. Use only supplied facts. "
        "Do not invent a person, role, menu item, partnership, price, revenue result or health benefit. "
        "Never use medical or functional health claims, including soothing/relieving/protecting the throat, "
        "detox, weight loss, immunity or disease language. Written messages may describe sensory experience, "
        "unsweetened tea, one-brick-one-pot operations, social rounds, menu upgrade and front-desk retail. "
        "Include a clear unsubscribe instruction and no purchase obligation. Keep under 180 words. "
        "Mention at most two verified observations with evidence_urls. "
        f"The sendable subject and body must be written in {'Arabic' if language == 'ar' else 'English'}. "
        "Also provide a faithful Simplified Chinese reference translation for human review. "
        "Return only valid JSON with keys: subject, body, subject_zh, body_zh, personalized_evidence, risk_flags."
    )
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "system", "content": instructions}, {"role": "user", "content": json.dumps(evidence, ensure_ascii=False)}],
        response_format={"type": "json_object"},
    )
    content = response.choices[0].message.content or "{}"
    data = json.loads(content)
    return {"subject": str(data.get("subject", "")).strip(), "body": str(data.get("body", "")).strip(), "subject_zh": str(data.get("subject_zh", "")).strip(), "body_zh": str(data.get("body_zh", "")).strip(), "personalized_evidence": str(data.get("personalized_evidence", "")).strip(), "evidence_urls": str(row.get("evidence_urls", ""))}


def main() -> int:
    ap = argparse.ArgumentParser(description="Generate outreach drafts without sending.")
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--provider", choices=["template", "openai", "deepseek"], default="template")
    ap.add_argument("--model", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--language", choices=["en", "ar"], default="en")
    args = ap.parse_args()
    with args.input.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    rows = [r for r in rows if str(r.get("qualified", "yes")).lower() == "yes"]
    if args.limit > 0:
        rows = rows[:args.limit]
    output = []
    for row in rows:
        if args.provider == "openai":
            model = args.model or os.getenv("OPENAI_MODEL", "")
            if not model:
                raise SystemExit("OPENAI_MODEL is required for --provider openai")
            draft = ai_draft(row, model)
        elif args.provider == "deepseek":
            model = args.model or os.getenv("DEEPSEEK_MODEL", "deepseek-flash")
            draft = deepseek_draft(row, model, args.language)
        else:
            draft = template_draft(row, args.language)
        evidence = split_items(draft.get("evidence_urls", ""))
        flags, status, notes = review_text(draft["subject"], draft["body"], evidence)
        output.append({**row, **draft, "draft_language": args.language, "draft_provider": args.provider, "risk_flags": ";".join(flags), "review_status": status, "review_notes": notes, "send_ready": "no"})
    fieldnames = list(rows[0].keys()) if rows else []
    for field in DRAFT_FIELDS:
        if field not in fieldnames:
            fieldnames.append(field)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader(); w.writerows(output)
    print(f"Drafted {len(output)} emails -> {args.output}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
