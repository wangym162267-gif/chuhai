#!/usr/bin/env python3
"""Enrich business leads from public website pages using only the standard library."""
from __future__ import annotations
import argparse, csv, json, re, time
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen
from urllib.robotparser import RobotFileParser

EMAIL_RE = re.compile(r"(?<![\w.+-])([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})(?![\w.-])", re.I)
SOCIAL_HOSTS = {"instagram": ("instagram.com",), "facebook": ("facebook.com",), "linkedin": ("linkedin.com",), "whatsapp": ("wa.me", "api.whatsapp.com")}
SIGNAL_TERMS = {
 "shisha": ["shisha", "hookah", "waterpipe", "narghile"],
 "cigar": ["cigar", "cigars", "humidor", "cigar lounge"],
 "lounge": ["lounge", "club", "bar", "nightlife"],
 "hotel": ["hotel", "resort", "five star", "5-star"],
 "luxury": ["luxury", "premium", "exclusive", "vip", "private", "members", "rooftop", "signature", "fine dining", "concierge", "reservation"],
 "social": ["event", "events", "dj", "live music", "sports", "football", "terrace", "group", "birthday", "private event", "social"],
 "tea": ["tea", "teapot", "pot of tea", "white tea", "black tea", "herbal tea", "chai", "moroccan tea"],
 "contact": ["contact", "reservation", "book now", "enquiry", "inquiry", "events", "private hire"],
}
ADDED_FIELDS = ["contact_page_url", "menu_url", "instagram_url", "facebook_url", "linkedin_url", "whatsapp_url", "public_business_email", "email_type", "detected_signals", "signal_counts", "website_title", "website_text_excerpt", "evidence_urls", "last_crawled_at", "crawl_status"]

class PageParser(HTMLParser):
 def __init__(self) -> None:
  super().__init__(convert_charrefs=True); self.text=[]; self.links=[]; self.emails=set(); self.title=""; self._skip=0; self._in_title=False
 def handle_starttag(self, tag, attrs):
  attrs_dict={k.lower():(v or "") for k,v in attrs}
  if tag in {"script","style","noscript","svg"}: self._skip+=1
  if tag=="title": self._in_title=True
  if tag=="a" and attrs_dict.get("href"):
   url=attrs_dict["href"].strip(); self.links.append(url)
   if url.lower().startswith("mailto:"): self.emails.add(url.split(":",1)[1].split("?",1)[0].strip().lower())
 def handle_endtag(self, tag):
  if tag in {"script","style","noscript","svg"} and self._skip: self._skip-=1
  if tag=="title": self._in_title=False
 def handle_data(self, data):
  if self._skip: return
  clean=" ".join(data.split())
  if not clean: return
  if self._in_title: self.title += (" " if self.title else "")+clean
  self.text.append(clean)

def request_text(url, timeout):
 req=Request(url, headers={"User-Agent":"DragonMonarchLeadResearch/1.0 (+public business research; contact site owner to opt out)"})
 with urlopen(req, timeout=timeout) as response:
  ctype=response.headers.get("content-type","")
  if not any(x in ctype for x in ("text/html","text/plain","xml")): raise ValueError(f"unsupported content type: {ctype}")
  raw=response.read(2_000_000); charset=response.headers.get_content_charset() or "utf-8"
  return raw.decode(charset,errors="replace"), response.geturl()

def same_site(base,candidate):
 try:
  a,b=urlparse(base),urlparse(candidate); ah,bh=(a.hostname or "").lower(),(b.hostname or "").lower()
  return bool(ah and bh and (bh==ah or bh.endswith("."+ah) or ah.endswith("."+bh)))
 except Exception: return False

def robots_allowed(url,timeout):
 try:
  parts=urlparse(url); parser=RobotFileParser(); parser.set_url(f"{parts.scheme}://{parts.netloc}/robots.txt"); parser.read(); return parser.can_fetch("*",url)
 except Exception: return True

def classify_email(email):
 local=email.split("@",1)[0].lower(); generic={"info","contact","hello","reservations","reservation","events","sales","marketing","admin","vip","booking","bookings","guest","guestservices"}
 return "generic" if local in generic else "public_named"

def extract_signals(text):
 low=text.lower(); counts={name:sum(low.count(term.lower()) for term in terms) for name,terms in SIGNAL_TERMS.items()}; return counts,[name for name,count in counts.items() if count>0]


def enrich_one(row,timeout,max_pages,delay):
 out=dict(row)
 for field in ADDED_FIELDS: out.setdefault(field,"")
 website=str(row.get("website") or "").strip()
 if not website: out["crawl_status"]="no_website"; return out
 if not website.startswith(("http://","https://")): website="https://"+website
 try: html,final_url=request_text(website,timeout)
 except Exception as exc: out["crawl_status"]=f"homepage_error: {type(exc).__name__}"; return out
 visited=set(); pages=[]; emails=set(); socials={}; candidate_links=[]
 def process(url,html_text):
  if url in visited or len(pages)>=max_pages: return
  visited.add(url); parser=PageParser(); parser.feed(html_text); pages.append((url,html_text,parser)); emails.update(parser.emails)
  joined=" ".join(parser.text); emails.update(m.group(1).lower() for m in EMAIL_RE.finditer(joined))
  for href in parser.links:
   absolute=urljoin(url,href); host=(urlparse(absolute).hostname or "").lower()
   for name,hosts in SOCIAL_HOSTS.items():
    if name not in socials and any(h in host for h in hosts): socials[name]=absolute
   if same_site(final_url,absolute): candidate_links.append(absolute)
 process(final_url,html)
 priority_terms=("contact","about","menu","event","reservation","book","private","vip")
 ranked=sorted(dict.fromkeys(candidate_links), key=lambda u:(not any(t in u.lower() for t in priority_terms),len(u)))
 for url in ranked:
  if len(pages)>=max_pages or not robots_allowed(url,timeout): continue
  try:
   time.sleep(max(delay,0)); page_html,page_url=request_text(url,timeout)
   if same_site(final_url,page_url): process(page_url,page_html)
  except Exception: continue
 all_text=" ".join(" ".join(p[2].text) for p in pages); counts,signals=extract_signals(all_text)
 urls_by_term={term:url for url,_,parser in pages for term in priority_terms if term in (url+" "+" ".join(parser.text)).lower()}
 title=next((p[2].title for p in pages if p[2].title),"")
 out.update({"contact_page_url":urls_by_term.get("contact",""),"menu_url":urls_by_term.get("menu",""),"instagram_url":socials.get("instagram",""),"facebook_url":socials.get("facebook",""),"linkedin_url":socials.get("linkedin",""),"whatsapp_url":socials.get("whatsapp",""),"public_business_email":";".join(sorted(emails)),"email_type":";".join(sorted({classify_email(e) for e in emails})),"detected_signals":";".join(signals),"signal_counts":json.dumps(counts,ensure_ascii=False),"website_title":title[:300],"website_text_excerpt":all_text[:1500],"evidence_urls":";".join(p[0] for p in pages),"last_crawled_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"crawl_status":"ok"})
 return out

def main():
 parser=argparse.ArgumentParser(description="Enrich leads using public website pages.")
 parser.add_argument("--input",required=True,type=Path); parser.add_argument("--output",required=True,type=Path); parser.add_argument("--timeout",type=float,default=15.0); parser.add_argument("--max-pages",type=int,default=4); parser.add_argument("--delay",type=float,default=0.4); parser.add_argument("--max-leads",type=int,default=0); args=parser.parse_args()
 with args.input.open("r",encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
 if args.max_leads>0: rows=rows[:args.max_leads]
 enriched=[enrich_one(row,args.timeout,args.max_pages,args.delay) for row in rows]
 fieldnames=list(rows[0].keys()) if rows else []
 for field in ADDED_FIELDS:
  if field not in fieldnames: fieldnames.append(field)
 args.output.parent.mkdir(parents=True,exist_ok=True)
 with args.output.open("w",encoding="utf-8-sig",newline="") as f:
  writer=csv.DictWriter(f,fieldnames=fieldnames,extrasaction="ignore"); writer.writeheader(); writer.writerows(enriched)
 print(f"Enriched {len(enriched)} leads -> {args.output}")

if __name__=="__main__": raise SystemExit(main())
