#!/usr/bin/env python3
"""Free lead discovery using Overture Maps Places (no Google API key required)."""
from __future__ import annotations
import argparse, csv, json, re, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
STRONG_RE = re.compile(r"(shisha|hookah|cigar|narghile)", re.I)
LOUNGE_RE = re.compile(r"lounge", re.I)
BAR_RE = re.compile(r"(^|[\s\-])(bar|cocktail|club|nightclub)($|[\s\-])", re.I)
BAD_NAME_RE = re.compile(r"(hookah market|vape|e-cigarette|tobacco|temporarily closed|car rental|rent a car|massage|spa|salon|clinic|hospital|apartment|hotel|restaurant|cafe|coffee|gym|fitness|barber|tailor|diamond|jewel|school|academy|bedspace|partition|pharmacy|supermarket|grocery|veterinary)", re.I)
GOOD_TYPES = {"hookah_bar", "cigar_bar", "cigar_lounge", "lounge", "bar", "cocktail_bar", "sports_bar", "night_club", "dance_club", "private_club"}
BAD_TYPES = {"airport_lounge", "beauty_salon", "barber", "gym", "spa", "medical_spa", "auto_dealer", "restaurant_equipment_and_supply", "pharmacy", "grocery_store", "hotel", "historic_site", "tobacco_shop", "vape_shop", "smoke_shop", "e_commerce_service"}
def primary_name(properties):
    return str((properties.get("names") or {}).get("primary") or "").strip()
def address_text(properties):
    a=(properties.get("addresses") or [{}])[0] or {}
    return ", ".join(str(x) for x in [a.get("freeform"),a.get("locality"),a.get("region"),a.get("country")] if x)
def type_text(properties):
    return str((properties.get("taxonomy") or {}).get("primary") or properties.get("basic_category") or "")
def eligible(name,typ):
    if BAD_NAME_RE.search(name): return False
    if STRONG_RE.search(name) or typ in {"hookah_bar","cigar_bar","cigar_lounge"}: return True
    if typ=="lounge" and LOUNGE_RE.search(name): return True
    if typ in {"cocktail_bar","sports_bar","dance_club","night_club","private_club"}: return True
    if typ=="bar" and BAR_RE.search(name): return True
    return False
def score(name,typ,website,phone,confidence):
    s=0; low=name.lower()
    if "hookah" in typ or "shisha" in low or "hookah" in low: s+=25
    elif "cigar" in typ or "cigar" in low: s+=25
    elif "lounge" in typ or "lounge" in low: s+=20
    elif any(x in typ for x in ("cocktail_bar","bar","club")): s+=16
    if website: s+=10
    if phone: s+=10
    if any(x in low for x in ("vip","premium","luxury","rooftop","terrace")): s+=5
    if confidence>=0.7: s+=5
    return min(s,75)
def run_download(bbox,dest):
    dest.parent.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,"-m","overturemaps","download",f"--bbox={bbox}","-f","geojson","--type=place","-o",str(dest)]
    print(" ".join(cmd),flush=True); subprocess.run(cmd,check=True)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--input",type=Path); ap.add_argument("--bbox"); ap.add_argument("--cache",type=Path); ap.add_argument("--city",required=True); ap.add_argument("--country",default="UAE"); ap.add_argument("--output",required=True,type=Path); ap.add_argument("--limit",type=int,default=100); ap.add_argument("--min-confidence",type=float,default=.35); args=ap.parse_args()
    source=args.input
    if source is None:
        source=args.cache or (args.output.parent/f"overture_{args.city.lower().replace(' ','_')}.geojson")
        if not source.exists():
            if not args.bbox: raise SystemExit("--bbox is required when cache does not exist")
            run_download(args.bbox,source)
    print(f"Reading {source}",flush=True); data=json.loads(source.read_text(encoding="utf-8")); now=datetime.now(timezone.utc).isoformat(); rows=[]; seen=set()
    for feature in data.get("features",[]):
        pr=feature.get("properties") or {}; name=primary_name(pr); typ=type_text(pr)
        if not name or typ in BAD_TYPES or not eligible(name, typ): continue
        website=(pr.get("websites") or [""])[0]; phone=(pr.get("phones") or [""])[0]
        if not website and not phone: continue
        confidence=float(pr.get("confidence") or 0)
        if confidence<args.min_confidence: continue
        pid=str(feature.get("id") or ""); key=pid or website or phone or name.lower()
        if key in seen: continue
        seen.add(key); s=score(name,typ,website,phone,confidence)
        rows.append({"lead_id":f"OV-{len(rows)+1:05d}","place_id":"overture:"+pid,"country":args.country,"city":args.city,"district":(pr.get("addresses") or [{}])[0].get("locality") or "","venue":name,"type":typ,"address":address_text(pr),"website":website,"public_business_phone":phone,"rating":"","review_count":"","business_status":"unknown","google_maps_url":"","source_query":"Overture Maps Places free search","source_url":website or "https://overturemaps.org/","source_date":now[:10],"retrieved_at":now,"icp_score":s,"priority":"A" if s>=60 else "B" if s>=45 else "C","qualified":"yes" if s>=45 else "no","detected_signals":typ,"notes":f"Overture confidence={confidence:.2f}; verify venue and contact before outreach.","public_business_email":"","consent_status":"未同意","stage":"待人工研究","next_action":"核验官网、菜单、邮箱与决策人","opt_out":"否"})
        if len(rows)>=args.limit: break
    rows.sort(key=lambda x:x["icp_score"],reverse=True); fields=list(rows[0].keys()) if rows else ["lead_id","place_id","country","city","district","venue","type","address","website","public_business_phone","icp_score","priority","qualified"]
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore"); w.writeheader(); w.writerows(rows)
    print(f"Wrote {len(rows)} free leads -> {args.output}",flush=True); return 0
if __name__=="__main__": raise SystemExit(main())
