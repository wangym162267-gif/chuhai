#!/usr/bin/env python3
"""Create a human review queue from generated drafts."""
from __future__ import annotations
import argparse, csv
from pathlib import Path
from draft_outreach import DRAFT_FIELDS, review_text, split_items

def main() -> int:
    ap = argparse.ArgumentParser(description="Review outreach drafts and queue them for a human.")
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    args = ap.parse_args()
    with args.input.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    reviewed = []
    for row in rows:
        flags, status, notes = review_text(str(row.get("subject", "")), str(row.get("body", "")), split_items(str(row.get("evidence_urls", ""))))
        reviewed.append({**row, "risk_flags": ";".join(flags), "review_status": status, "review_notes": notes, "human_decision": "pending", "send_ready": "no"})
    fields = list(rows[0].keys()) if rows else []
    for field in ["human_decision", "send_ready"]:
        if field not in fields:
            fields.append(field)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader(); w.writerows(reviewed)
    print(f"Queued {len(reviewed)} drafts for human review -> {args.output}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
