#!/usr/bin/env python3
"""Thin CLI orchestrator for the B2B prospecting MVP."""
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
PARENT = HERE.parent

def run(parts: list[str]) -> int:
    print("RUN", " ".join(parts))
    return subprocess.call(parts)

def main() -> int:
    ap = argparse.ArgumentParser(description="AI B2B prospecting MVP pipeline.")
    sub = ap.add_subparsers(dest="command", required=True)
    d = sub.add_parser("discover", help="Discover venues with Google Places API")
    d.add_argument("--queries", required=True, type=Path); d.add_argument("--output", required=True, type=Path); d.add_argument("--language", default="en"); d.add_argument("--region", default=""); d.add_argument("--max-per-query", type=int, default=20)
    e = sub.add_parser("enrich", help="Enrich leads from public websites")
    e.add_argument("--input", required=True, type=Path); e.add_argument("--output", required=True, type=Path); e.add_argument("--max-leads", type=int, default=0)
    s = sub.add_parser("score", help="Score leads against ICP")
    s.add_argument("--input", required=True, type=Path); s.add_argument("--output", required=True, type=Path); s.add_argument("--qualified-only", action="store_true")
    dr = sub.add_parser("draft", help="Generate personalized drafts")
    dr.add_argument("--input", required=True, type=Path); dr.add_argument("--output", required=True, type=Path); dr.add_argument("--provider", choices=["template", "openai", "deepseek"], default="template"); dr.add_argument("--model", default=""); dr.add_argument("--limit", type=int, default=0)
    dr.add_argument("--language", choices=["en", "ar"], default="en")
    rv = sub.add_parser("review", help="Create a human review queue")
    rv.add_argument("--input", required=True, type=Path); rv.add_argument("--output", required=True, type=Path)
    apv = sub.add_parser("approve", help="Approve selected drafts without sending")
    apv.add_argument("--input", required=True, type=Path); apv.add_argument("--output", required=True, type=Path); apv.add_argument("--lead-id", action="append", default=[]); apv.add_argument("--reviewer", required=True); apv.add_argument("--allow-needs-review", action="store_true")
    args = ap.parse_args(); py = sys.executable
    if args.command == "discover":
        return run([py, str(PARENT / "gmb_leads_exporter.py"), "--queries", str(args.queries), "--output", str(args.output), "--language", args.language, "--region", args.region, "--max-per-query", str(args.max_per_query)])
    if args.command == "enrich":
        return run([py, str(HERE / "enrich_leads.py"), "--input", str(args.input), "--output", str(args.output), "--max-leads", str(args.max_leads)])
    if args.command == "score":
        cmd = [py, str(HERE / "score_leads.py"), "--input", str(args.input), "--output", str(args.output)]
        if args.qualified_only: cmd.append("--qualified-only")
        return run(cmd)
    if args.command == "draft":
        cmd = [py, str(HERE / "draft_outreach.py"), "--input", str(args.input), "--output", str(args.output), "--provider", args.provider, "--limit", str(args.limit), "--language", args.language]
        if args.model: cmd += ["--model", args.model]
        return run(cmd)
    if args.command == "review":
        return run([py, str(HERE / "review_outreach.py"), "--input", str(args.input), "--output", str(args.output)])
    if args.command == "approve":
        cmd = [py, str(HERE / "approve_drafts.py"), "--input", str(args.input), "--output", str(args.output), "--reviewer", args.reviewer]
        for lead_id in args.lead_id: cmd += ["--lead-id", lead_id]
        if args.allow_needs_review: cmd.append("--allow-needs-review")
        return run(cmd)
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
