#!/usr/bin/env python3
"""Rule-based ICP scoring for shisha/cigar lounge leads."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
from typing import Any
SCORE_FIELDS=["icp_score","priority","score_breakdown","score_reasons","qualified","disqualification_reason","needs_human_review"]
def load_json(path:Path)->dict[str,Any]:
 with path.open("r",encoding="utf-8-sig") as f: return json.load(f)
def text_of(row:dict[str,Any])->str:
 keys=("venue","type","address","website_title","website_text_excerpt","detected_signals","source_query","public_business_email")
 return " ".join(str(row.get(k,"")) for k in keys).lower()
def bounded(points:int,maximum:int)->int: return max(0,min(points,maximum))
def score_lead(row:dict[str,Any],profile:dict[str,Any])->dict[str,Any]:
 t=text_of(row); weights=profile["weights"]; breakdown={}; reasons=[]
 country=str(row.get("country","")); city=str(row.get("city","")); district=str(row.get("district",""))
 market=weights["market"] if country in profile["target_countries"] or city in profile["target_cities"] else 0
 if district in profile["target_districts"]: market=weights["market"]
 breakdown["market"]=market; reasons.append(f"market={market}")
 venue=0
 for key,points in profile["venue_type_points"].items():
  if key in t: venue=max(venue,points) if points>=0 else min(venue,points)
 venue=bounded(venue,weights["venue_type"]); breakdown["venue_type"]=max(venue,0); reasons.append(f"venue_type={max(venue,0)}")
 luxury_hits=[k for k in profile["luxury_keywords"] if k in t]; luxury=bounded(len(luxury_hits)*4,weights["luxury"]); breakdown["luxury"]=luxury; reasons.append("luxury="+",".join(luxury_hits[:5]) if luxury_hits else "luxury=0")
 social_hits=[k for k in profile["social_keywords"] if k in t]; social=bounded(len(social_hits)*3,weights["social"]); breakdown["social"]=social; reasons.append("social="+",".join(social_hits[:5]) if social_hits else "social=0")
 tea_hits=[k for k in profile["tea_keywords"] if k in t]; tea=bounded(len(tea_hits)*4,weights["tea"]); breakdown["tea"]=tea; reasons.append("tea="+",".join(tea_hits[:5]) if tea_hits else "tea=0")
 email=str(row.get("public_business_email","")).strip(); phone=str(row.get("public_business_phone","")).strip(); contact=weights["contactability"] if email else (weights["contactability"]//2 if phone else 0)
 breakdown["contactability"]=contact; reasons.append("contactability="+str(contact))
 decision=weights["decision_path"] if any(k in t for k in ("owner","founder","manager","marketing","f&b","operations")) or str(row.get("linkedin_url","")).strip() else 0
 breakdown["decision_path"]=decision; reasons.append("decision_path="+str(decision))
 try: rating=float(row.get("rating") or 0); reviews=int(float(row.get("review_count") or 0))
 except ValueError: rating=0; reviews=0
 activity=0
 if str(row.get("business_status","")).upper()=="OPERATIONAL": activity+=2
 if rating>=4.5: activity+=2
 elif rating>=4.0: activity+=1
 if reviews>=200: activity+=1
 activity=bounded(activity,weights["activity"]); breakdown["activity"]=activity; reasons.append("activity="+str(activity))
 score=sum(breakdown.values()); disqualifiers=[k for k in profile["disqualify_keywords"] if k in t]; reason=""
 if disqualifiers: reason="disqualify_keywords: "+",".join(disqualifiers)
 elif not (email or phone): reason="no_public_business_contact"
 elif str(row.get("business_status","")).upper() not in ("OPERATIONAL",""): reason="not_operational"
 qualified=score>=profile["minimum_qualified_score"] and not reason
 priority="A" if qualified and score>=profile["priority_thresholds"]["A"] else "B" if qualified else "C"
 return {**row,"icp_score":score,"priority":priority,"score_breakdown":json.dumps(breakdown,ensure_ascii=False),"score_reasons":"; ".join(reasons),"qualified":"yes" if qualified else "no","disqualification_reason":reason,"needs_human_review":"yes"}
def main():
 ap=argparse.ArgumentParser(description="Score leads against ICP profile.")
 ap.add_argument("--input",required=True,type=Path); ap.add_argument("--output",required=True,type=Path); ap.add_argument("--profile",type=Path,default=Path(__file__).with_name("config")/"icp_profile.json"); ap.add_argument("--qualified-only",action="store_true"); args=ap.parse_args()
 profile=load_json(args.profile)
 with args.input.open("r",encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
 scored=[score_lead(r,profile) for r in rows]
 if args.qualified_only: scored=[r for r in scored if r["qualified"]=="yes"]
 fieldnames=list(rows[0].keys()) if rows else []
 for field in SCORE_FIELDS:
  if field not in fieldnames: fieldnames.append(field)
 args.output.parent.mkdir(parents=True,exist_ok=True)
 with args.output.open("w",encoding="utf-8-sig",newline="") as f:
  w=csv.DictWriter(f,fieldnames=fieldnames,extrasaction="ignore"); w.writeheader(); w.writerows(scored)
 print(f"Scored {len(scored)} leads -> {args.output}")
if __name__=="__main__": raise SystemExit(main())
