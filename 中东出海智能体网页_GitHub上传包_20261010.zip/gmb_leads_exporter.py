#!/usr/bin/env python3
"""Export public business places via Google Places API (New).

This script intentionally uses the official API only. Review current Google Maps
Platform terms before storing, displaying, or reusing any returned content.

Usage:
  export GOOGLE_MAPS_API_KEY="..."
  python gmb_leads_exporter.py --queries queries_sample.csv --output leads_raw.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

ENDPOINT = "https://places.googleapis.com/v1/places:searchText"
FIELD_MASK = ",".join([
    "places.id",
    "places.displayName",
    "places.formattedAddress",
    "places.websiteUri",
    "places.nationalPhoneNumber",
    "places.internationalPhoneNumber",
    "places.primaryTypeDisplayName",
    "places.rating",
    "places.userRatingCount",
    "places.businessStatus",
    "places.googleMapsUri",
    "places.regularOpeningHours.weekdayDescriptions",
    "nextPageToken",
])
OUTPUT_FIELDS = [
    "lead_id", "place_id", "country", "city", "district", "venue", "type", "address",
    "website", "public_business_phone", "rating", "review_count", "business_status",
    "google_maps_url", "source_query", "source_url", "source_date", "retrieved_at",
    "retention_review_date", "auto_icp_score", "priority", "public_business_email",
    "contact_name", "role", "consent_status", "stage", "next_action", "next_date",
    "sample_sku", "courier", "tracking_no", "signed_by", "reply_summary",
    "objection", "opt_out", "owner", "notes",
]


def eprint(*args: Any) -> None:
    print(*args, file=sys.stderr)


def request_json(url: str, api_key: str, body: dict[str, Any]) -> dict[str, Any]:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Goog-Api-Key": api_key,
            "X-Goog-FieldMask": FIELD_MASK,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Places API HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Places API network error: {exc}") from exc


def read_queries(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    required = {"query"}
    if not rows or not required.issubset(rows[0].keys()):
        raise ValueError("Query CSV must include a 'query' column.")
    return rows


def localized(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("text") or value.get("name") or "")
    return str(value or "")


def auto_score(place: dict[str, Any], search_blob: str) -> int:
    text = " ".join([
        localized(place.get("displayName")),
        str(place.get("formattedAddress") or ""),
        localized(place.get("primaryTypeDisplayName")),
        search_blob,
    ]).lower()
    score = 0
    if any(word in text for word in ("lounge", "shisha", "hookah", "cigar", "club", "bar")):
        score += 20
    elif any(word in text for word in ("restaurant", "cafe", "coffee", "hotel")):
        score += 10
    rating = place.get("rating")
    if isinstance(rating, (int, float)):
        if rating >= 4.5:
            score += 10
        elif rating >= 4.2:
            score += 6
    reviews = place.get("userRatingCount") or 0
    if isinstance(reviews, int):
        if reviews >= 500:
            score += 15
        elif reviews >= 200:
            score += 10
        elif reviews >= 50:
            score += 5
    if place.get("websiteUri"):
        score += 5
    if place.get("internationalPhoneNumber") or place.get("nationalPhoneNumber"):
        score += 5
    if place.get("googleMapsUri"):
        score += 5
    if place.get("businessStatus") == "OPERATIONAL":
        score += 5
    return min(score, 65)


def priority(score: int) -> str:
    # Auto score tops out at 65. Manual menu/decision-maker evidence is required
    # before a lead can become A/B.
    if score >= 55:
        return "待人工评级-高"
    if score >= 35:
        return "待人工评级-中"
    return "待人工评级-低"


def place_key(place: dict[str, Any]) -> str:
    place_id = str(place.get("id") or "").strip()
    if place_id:
        return "id:" + place_id
    website = str(place.get("websiteUri") or "").strip().lower().rstrip("/")
    if website:
        return "web:" + website
    phone = str(place.get("internationalPhoneNumber") or place.get("nationalPhoneNumber") or "").strip()
    if phone:
        return "phone:" + phone
    return "name:" + localized(place.get("displayName")).lower() + "|" + str(place.get("formattedAddress") or "").lower()


def flatten(place: dict[str, Any], query_row: dict[str, str], sequence: int) -> dict[str, Any]:
    query = query_row.get("query", "").strip()
    now = datetime.now(timezone.utc)
    website = str(place.get("websiteUri") or "")
    maps_url = str(place.get("googleMapsUri") or "")
    source_url = maps_url or website
    return {
        "lead_id": f"RAW-{sequence:05d}",
        "place_id": str(place.get("id") or ""),
        "country": query_row.get("country", ""),
        "city": query_row.get("city", ""),
        "district": query_row.get("district", ""),
        "venue": localized(place.get("displayName")),
        "type": localized(place.get("primaryTypeDisplayName")),
        "address": str(place.get("formattedAddress") or ""),
        "website": website,
        "public_business_phone": str(place.get("internationalPhoneNumber") or place.get("nationalPhoneNumber") or ""),
        "rating": place.get("rating", ""),
        "review_count": place.get("userRatingCount", ""),
        "business_status": str(place.get("businessStatus") or ""),
        "google_maps_url": maps_url,
        "source_query": query,
        "source_url": source_url,
        "source_date": now.date().isoformat(),
        "retrieved_at": now.isoformat(),
        "retention_review_date": "",
        "auto_icp_score": auto_score(place, query),
        "priority": priority(auto_score(place, query)),
        "public_business_email": "",
        "contact_name": "",
        "role": "",
        "consent_status": "未同意",
        "stage": "待人工研究",
        "next_action": "核验菜单、业务邮箱、决策人与合规来源",
        "next_date": "",
        "sample_sku": "",
        "courier": "",
        "tracking_no": "",
        "signed_by": "",
        "reply_summary": "",
        "objection": "",
        "opt_out": "否",
        "owner": "",
        "notes": "仅使用公开业务资料；联系前完成人工评分与合规检查。",
    }


def search_query(api_key: str, row: dict[str, str], language: str, region: str, pause: float) -> Iterable[dict[str, Any]]:
    token: str | None = None
    seen_tokens: set[str] = set()
    while True:
        body: dict[str, Any] = {
            "textQuery": row["query"],
            "pageSize": 20,
            "languageCode": language or "en",
        }
        if region:
            body["regionCode"] = region
        if token:
            if token in seen_tokens:
                break
            seen_tokens.add(token)
            body["pageToken"] = token
        payload = request_json(ENDPOINT, api_key, body)
        for place in payload.get("places", []):
            yield place
        token = payload.get("nextPageToken")
        if not token:
            break
        time.sleep(max(pause, 0))


def main() -> int:
    parser = argparse.ArgumentParser(description="Export public business places via Google Places API (New).")
    parser.add_argument("--queries", required=True, type=Path, help="CSV with at least a query column")
    parser.add_argument("--output", required=True, type=Path, help="Output CSV")
    parser.add_argument("--language", default="en", help="Places languageCode")
    parser.add_argument("--region", default="", help="Places regionCode, e.g. AE, SA, QA")
    parser.add_argument("--pause", type=float, default=2.0, help="Seconds between paginated requests")
    parser.add_argument("--max-per-query", type=int, default=20, help="Safety cap; API may return up to 60")
    args = parser.parse_args()

    api_key = os.environ.get("GOOGLE_MAPS_API_KEY", "").strip()
    if not api_key:
        eprint("ERROR: GOOGLE_MAPS_API_KEY is not set.")
        return 2

    try:
        query_rows = read_queries(args.queries)
    except Exception as exc:
        eprint(f"ERROR: {exc}")
        return 2

    seen: set[str] = set()
    output_rows: list[dict[str, Any]] = []
    for row in query_rows:
        count = 0
        eprint(f"Searching: {row['query']}")
        try:
            for place in search_query(api_key, row, args.language, args.region, args.pause):
                key = place_key(place)
                if key in seen:
                    continue
                seen.add(key)
                output_rows.append(flatten(place, row, len(output_rows) + 1))
                count += 1
                if count >= args.max_per_query:
                    break
            time.sleep(max(args.pause, 0))
        except Exception as exc:
            eprint(f"WARN: query failed: {row['query']}: {exc}")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        writer.writerows(output_rows)
    eprint(f"Wrote {len(output_rows)} unique places to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
