@echo off
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py"
start "Dragon Monarch Web Console" /min %PY% "web_console\server.py" --host 127.0.0.1 --port 8765
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8765"
