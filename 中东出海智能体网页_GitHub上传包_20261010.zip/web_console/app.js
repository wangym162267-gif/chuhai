const state = { leads: [], drafts: [], dashboard: null, selectedDraft: null, selectedReview: null };
const $ = (id) => document.getElementById(id);
const fmt = (n) => Number(n || 0).toLocaleString('zh-CN');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path, options={}) {
  const r = await fetch(path, {headers:{'Content-Type':'application/json'}, ...options});
  if (!r.ok) throw new Error((await r.json()).error || `HTTP ${r.status}`);
  return r.json();
}
function toast(msg) { const t=$('toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2400); }
function switchPage(name) {
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active', x.dataset.page===name));
  document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active', x.id===`page-${name}`));
  $('page-title').textContent = ({dashboard:'总览',discover:'客户发现',outreach:'开发信',review:'人工审查',settings:'设置'})[name];
  if (name==='dashboard') loadDashboard();
  if (name==='discover') loadLeads();
  if (name==='outreach') loadDrafts();
  if (name==='review') loadReview();
  if (name==='settings') loadSettings();
}
function barChart(items, target) {
  const max = Math.max(...items.map(x=>Number(x.value)||0), 1);
  $(target).innerHTML = items.map(x=>`<div class="bar-row"><span>${esc(x.name)}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.max(4,(Number(x.value)||0)/max*100)}%"></div></div><b class="bar-value">${fmt(x.value)}</b></div>`).join('');
}
function renderDashboard(data) {
  state.dashboard = data; $('demo-badge').hidden = !data.demo;
  $('metric-leads').textContent = fmt(data.metrics.leads);
  $('metric-qualified').textContent = fmt(data.metrics.qualified);
  $('metric-drafts').textContent = fmt(data.metrics.drafts);
  $('metric-review').textContent = fmt(data.metrics.pending_review);
  $('metric-contact-rate').textContent = `可联系率 ${data.metrics.contact_rate}%`;
  $('metric-qualified-rate').textContent = `合格率 ${data.metrics.qualified_rate}%`;
  barChart(data.funnel, 'funnel-chart'); barChart(data.cities, 'city-chart');
  $('recent-table').innerHTML = data.recent.map(r=>`<tr><td><strong>${esc(r.venue)}</strong></td><td>${esc(r.city)}</td><td>${esc(r.type)}</td><td><span class="score-pill">${esc(r.icp_score||'-')}</span></td><td><span class="priority-pill priority-${esc(r.priority||'C')}">${esc(r.priority||'C')}</span></td><td><span class="status-pill">${esc(r.stage||'待处理')}</span></td></tr>`).join('');
}
async function loadDashboard(){ try{ renderDashboard(await api('/api/dashboard')); }catch(e){ toast('总览加载失败: '+e.message); } }
async function loadLeads(){
  try{
    const q = $('lead-search')?.value || '';
    const data = await api('/api/leads?q='+encodeURIComponent(q));
    state.leads=data.rows; $('lead-source').textContent=data.source + (data.demo?' · 演示数据':'');
    $('leads-table').innerHTML=data.rows.map(r=>`<tr><td><strong>${esc(r.venue)}</strong></td><td>${esc(r.city)} / ${esc(r.district||'')}</td><td>${r.public_business_phone?`<a href="tel:${esc(r.public_business_phone)}">${esc(r.public_business_phone)}</a>`:''}${r.website?`<div><a href="${esc(r.website)}" target="_blank" rel="noreferrer">官网</a></div>`:''}${!r.public_business_phone&&!r.website?'待补全':''}</td><td><span class="score-pill">${esc(r.icp_score||'-')}</span></td><td><span class="priority-pill priority-${esc(r.priority||'C')}">${esc(r.priority||'C')}</span></td><td><span class="status-pill">${esc(r.stage||r.qualified||'待处理')}</span></td></tr>`).join('');
  }catch(e){ toast('客户列表加载失败: '+e.message); }
}
async function loadDrafts(){
  try{
    const data=await api('/api/drafts'); state.drafts=data.rows;
    $('draft-list').innerHTML=data.rows.map((r,i)=>`<div class="record" data-draft="${i}"><strong>${esc(r.venue||r.subject||'未命名草稿')}</strong><span>${esc(r.review_status||'待审核')} · ${esc(r.subject||'')}</span></div>`).join('') || '<p class="muted-text">暂无草稿。点击“生成开发信草稿”。</p>';
    document.querySelectorAll('[data-draft]').forEach(el=>el.onclick=()=>showDraft(Number(el.dataset.draft)));
  }catch(e){ toast('草稿加载失败: '+e.message); }
}
function showDraft(i){
  const r=state.drafts[i]; if(!r) return; state.selectedDraft=r;
  $('draft-meta').textContent=`${r.venue||''} · ${r.draft_provider||'草稿'} · ${r.review_status||'待审核'}`;
  $('subject-zh').value=r.subject_zh||r.subject||'';
  $('body-zh').value=r.body_zh||r.body||'';
  $('subject-target').value=r.subject||'';
  $('body-target').value=r.body||'';
  $('draft-language').value=r.draft_language||'en';
}

async function loadReview(){
  try{
    const data=await api('/api/drafts'); const rows=data.rows;
    const pending=rows.filter(r=>String(r.human_decision||'pending').toLowerCase()==='pending').length;
    const approved=rows.filter(r=>String(r.human_decision||'').toLowerCase()==='approved'||String(r.send_ready||'').toLowerCase()==='yes').length;
    const needs=rows.filter(r=>String(r.review_status||'')==='needs_review').length;
    $('review-pending').textContent=fmt(pending); $('review-approved').textContent=fmt(approved); $('review-needs').textContent=fmt(needs);
    $('review-table').innerHTML=rows.map((r,i)=>`<tr><td><input type="checkbox" class="review-check" data-id="${esc(r.lead_id||r.place_id||i)}"></td><td><strong>${esc(r.venue||'未命名')}</strong><div class="muted-text">${esc(r.subject||'')}</div></td><td><span class="score-pill">${esc(r.icp_score||'-')}</span></td><td>${esc(r.risk_flags||'无')}</td><td><span class="status-pill">${esc(r.human_decision||'pending')}</span></td><td><a href="${esc(r.evidence_urls||'#')}" target="_blank" rel="noreferrer">查看证据</a></td></tr>`).join('');
    document.querySelectorAll('#review-table tr').forEach((tr,i)=>{tr.onclick=(e)=>{if(e.target.tagName!=='INPUT') showReview(rows[i]);};});
  }catch(e){toast('审核队列加载失败: '+e.message);}
}
function showReview(r){state.selectedReview=r;$('review-meta').textContent=`${r.venue||''} · ${r.human_decision||'pending'} · ${r.draft_language||'en'}`;$('review-detail').textContent=`门店：${r.venue||''}\nICP：${r.icp_score||'-'}\n风险：${r.risk_flags||'无'}\n证据：${r.evidence_urls||'无'}\n\n【中文审核版】\n主题：${r.subject_zh||r.subject||''}\n\n${r.body_zh||r.body||''}\n\n【目标语言发送版】\n主题：${r.subject||''}\n\n${r.body||''}`;}
async function loadSettings(){
  try{
    const s=await api('/api/settings');
    $('setting-deepseek-model').value=s.deepseek_model||'deepseek-flash';
    $('setting-sender-name').value=s.sender_name||'';$('setting-sender-email').value=s.sender_email||'';$('setting-sender-phone').value=s.sender_phone||'';
    $('settings-state').textContent=`Google ${s.has_google?'已配置':'未配置'} · DeepSeek ${s.has_deepseek?'已配置':'未配置'}`;
  }catch(e){toast('设置加载失败: '+e.message);}
}
async function saveSettings(){
  const payload={deepseek_key:$('setting-deepseek').value.trim(),deepseek_model:$('setting-deepseek-model').value.trim(),google_key:$('setting-google').value.trim(),openai_key:$('setting-openai').value.trim(),sender_name:$('setting-sender-name').value.trim(),sender_email:$('setting-sender-email').value.trim(),sender_phone:$('setting-sender-phone').value.trim()};
  Object.keys(payload).forEach(k=>{if(!payload[k])delete payload[k];});
  try{await api('/api/settings',{method:'POST',body:JSON.stringify(payload)});toast('设置已保存到本机');loadSettings();}catch(e){toast('保存失败: '+e.message);}
}
async function startJob(kind,payload,title){
  try{
    const r=await api('/api/jobs',{method:'POST',body:JSON.stringify({kind,payload})});
    $('job-title').textContent=title; $('job-log').textContent='任务已创建，等待日志...'; $('log-drawer').classList.add('open'); pollJob(r.job_id);
  }catch(e){toast('任务启动失败: '+e.message);}
}
async function pollJob(id){
  try{
    const job=await api('/api/jobs/'+id);
    $('job-log').textContent=(job.logs||[]).join('\n')||'运行中...'; $('job-log').scrollTop=$('job-log').scrollHeight;
    if(job.status==='done'){toast('任务完成');setTimeout(()=>{loadDashboard();loadLeads();loadDrafts();loadReview();},500);return;}
    if(job.status==='failed'){toast('任务失败，请查看日志');return;}
    setTimeout(()=>pollJob(id),1000);
  }catch(e){toast('任务状态读取失败: '+e.message);}
}
document.querySelectorAll('.nav-item').forEach(btn=>btn.onclick=()=>switchPage(btn.dataset.page));
document.querySelectorAll('[data-jump]').forEach(btn=>btn.onclick=()=>switchPage(btn.dataset.jump));
$('refresh-btn').onclick=()=>{loadDashboard();loadLeads();loadDrafts();loadReview();toast('已刷新');};
$('close-log').onclick=()=>$('log-drawer').classList.remove('open');
$('lead-search').oninput=()=>loadLeads();
$('run-discover').onclick=()=>startJob('discover',{region:$('discover-region').value,type:$('discover-type').value,keyword:$('discover-keyword').value,rating:$('discover-rating').value},'Google搜索客户');
$('run-discover-free').onclick=()=>startJob('discover_free',{city:$('discover-city').value},'免费搜索客户');
$('run-enrich').onclick=()=>startJob('enrich',{},'补全公开业务资料');
$('run-score').onclick=()=>startJob('score',{},'执行 ICP 评分');
$('run-draft').onclick=()=>startJob('draft',{provider:$('draft-provider').value,language:$('draft-language').value,limit:Number($('draft-limit').value||5),model:$('draft-provider').value==='deepseek'?$('setting-deepseek-model').value:''},'生成开发信');
$('save-settings').onclick=saveSettings;
$('translate-edited').onclick=async()=>{
  if(!state.selectedDraft){toast('请先选择草稿');return;}
  try{const r=await api('/api/translate',{method:'POST',body:JSON.stringify({target_language:$('draft-language').value,subject_zh:$('subject-zh').value,body_zh:$('body-zh').value})});$('subject-target').value=r.subject;$('body-target').value=r.body;toast('已重新翻译');}catch(e){toast('翻译失败: '+e.message);}
};
$('save-review').onclick=async()=>{
  if(!state.selectedDraft){toast('请先选择草稿');return;}
  const payload={...state.selectedDraft,subject:$('subject-target').value,body:$('body-target').value,subject_zh:$('subject-zh').value,body_zh:$('body-zh').value,draft_language:$('draft-language').value,review_status:'needs_review',human_decision:'pending',send_ready:'no'};
  try{await api('/api/draft/save',{method:'POST',body:JSON.stringify(payload)});toast('已送入人工审查');loadReview();}catch(e){toast('保存失败: '+e.message);}
};
$('approve-selected').onclick=()=>{
  const ids=[...document.querySelectorAll('.review-check:checked')].map(x=>x.dataset.id);
  if(!ids.length){toast('请先选择需要批准的草稿');return;}
  startJob('approve',{lead_ids:ids,reviewer:'Owner'},'人工批准草稿（不会自动发送）');
};
(async function init(){await loadDashboard();await loadLeads();await loadDrafts();await loadReview();await loadSettings();})();
