#!/usr/bin/env python3
"""Local web console for the Dragon Monarch Middle East prospecting workflow."""
from __future__ import annotations
import csv, json, os, subprocess, sys, threading, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

WEB_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = WEB_ROOT.parent.parent
AGENT_ROOT = WEB_ROOT.parent / "agent_mvp"
PIPELINE = AGENT_ROOT / "run_pipeline.py"
DATA_DIR = AGENT_ROOT / "data"
SETTINGS_PATH = AGENT_ROOT / "settings.json"
JOBS = {}
JOBS_LOCK = threading.Lock()
DEMO_LEADS = [
 {"place_id":"demo-001","venue":"The Cigar Room DIFC","city":"Dubai","district":"DIFC","type":"Cigar Lounge","rating":"4.8","review_count":"820","public_business_email":"info@cigarroom-demo.com","public_business_phone":"+971 4 000 1001","icp_score":"92","priority":"A","qualified":"yes","stage":"待开发信","review_status":"pending","human_decision":"pending","detected_signals":"cigar;lounge;luxury;social"},
 {"place_id":"demo-002","venue":"Silver Palm Lounge","city":"Dubai","district":"JBR","type":"Shisha Lounge","rating":"4.6","review_count":"640","public_business_email":"hello@silverpalm-demo.com","public_business_phone":"+971 4 000 1002","icp_score":"86","priority":"A","qualified":"yes","stage":"待开发信","review_status":"pending","human_decision":"pending","detected_signals":"shisha;lounge;social;tea"},
 {"place_id":"demo-003","venue":"Al Maryah Cigar Club","city":"Abu Dhabi","district":"Al Maryah Island","type":"Cigar Lounge","rating":"4.7","review_count":"510","public_business_email":"events@maryahcigar-demo.com","public_business_phone":"+971 2 000 1003","icp_score":"84","priority":"A","qualified":"yes","stage":"待审核","review_status":"needs_review","human_decision":"pending","detected_signals":"cigar;lounge;luxury;events"},
 {"place_id":"demo-004","venue":"Pearl Night Lounge","city":"Doha","district":"The Pearl","type":"Shisha Lounge","rating":"4.5","review_count":"430","public_business_email":"bookings@pearlnight-demo.com","public_business_phone":"+974 4000 1004","icp_score":"79","priority":"B","qualified":"yes","stage":"待开发信","review_status":"pending","human_decision":"pending","detected_signals":"shisha;lounge;social"},
 {"place_id":"demo-005","venue":"KAFD Business Cigar","city":"Riyadh","district":"KAFD","type":"Cigar Lounge","rating":"4.4","review_count":"290","public_business_email":"contact@kafdcigar-demo.com","public_business_phone":"+966 11 000 1005","icp_score":"76","priority":"B","qualified":"yes","stage":"已寄样","review_status":"pending","human_decision":"pending","detected_signals":"cigar;lounge;luxury"},
 {"place_id":"demo-006","venue":"Tahlia Terrace","city":"Riyadh","district":"Tahlia Street","type":"Shisha Lounge","rating":"4.3","review_count":"310","public_business_email":"info@tahliaterrace-demo.com","public_business_phone":"+966 11 000 1006","icp_score":"72","priority":"B","qualified":"yes","stage":"试摆中","review_status":"pending","human_decision":"pending","detected_signals":"shisha;lounge;terrace;events"},
 {"place_id":"demo-007","venue":"Corniche Gold Lounge","city":"Jeddah","district":"Corniche","type":"Shisha Lounge","rating":"4.5","review_count":"520","public_business_email":"vip@cornichegold-demo.com","public_business_phone":"+966 12 000 1007","icp_score":"78","priority":"B","qualified":"yes","stage":"待联系","review_status":"pending","human_decision":"pending","detected_signals":"shisha;lounge;vip;social"},
 {"place_id":"demo-008","venue":"West Bay Members Bar","city":"Doha","district":"West Bay","type":"Hotel Bar","rating":"4.6","review_count":"370","public_business_email":"events@westbaymembers-demo.com","public_business_phone":"+974 4000 1008","icp_score":"74","priority":"B","qualified":"yes","stage":"待联系","review_status":"pending","human_decision":"pending","detected_signals":"hotel;bar;members;events"},
 {"place_id":"demo-009","venue":"Skyline Shisha Club","city":"Dubai","district":"Business Bay","type":"Shisha Lounge","rating":"4.2","review_count":"180","public_business_email":"info@skylineclub-demo.com","public_business_phone":"+971 4 000 1009","icp_score":"68","priority":"B","qualified":"yes","stage":"待联系","review_status":"pending","human_decision":"pending","detected_signals":"shisha;club;social"},
 {"place_id":"demo-010","venue":"Olaya Premium Cafe","city":"Riyadh","district":"Al Olaya","type":"Cafe","rating":"4.1","review_count":"150","public_business_email":"hello@olayacafe-demo.com","public_business_phone":"+966 11 000 1010","icp_score":"54","priority":"C","qualified":"no","stage":"已淘汰","review_status":"pending","human_decision":"rejected","detected_signals":"cafe;tea"},
 {"place_id":"demo-011","venue":"Marina Vape and Tobacco","city":"Dubai","district":"Dubai Marina","type":"Tobacco Retailer","rating":"4.0","review_count":"90","public_business_email":"sales@marinavape-demo.com","public_business_phone":"+971 4 000 1011","icp_score":"28","priority":"C","qualified":"no","stage":"已淘汰","review_status":"pending","human_decision":"rejected","detected_signals":"tobacco;retail"},
 {"place_id":"demo-012","venue":"Lusail Executive Lounge","city":"Doha","district":"Lusail","type":"Private Club","rating":"4.7","review_count":"460","public_business_email":"members@lusail-exec-demo.com","public_business_phone":"+974 4000 1012","icp_score":"88","priority":"A","qualified":"yes","stage":"已回复","review_status":"pass","human_decision":"approved","detected_signals":"private;club;luxury;members;events"}
]

DEMO_DRAFTS = [
 {"place_id":"demo-001","venue":"The Cigar Room DIFC","subject":"A one-brick tea ritual for The Cigar Room DIFC","body":"Hello The Cigar Room DIFC team,\n\nI am [Sender Name] from Dragon Monarch. We produce pressed whole-leaf tea for premium cigar lounges: one brick, one pot, no scales and no tea training required.\n\nYour venue is located in DIFC and its public pages signal a cigar, luxury and social experience. We are selecting a small number of venues in Dubai for a 14-day pilot kit.\n\nWould you like me to send the pilot kit to your business address? There is no purchase obligation.\n\nReply unsubscribe to opt out.\n\nBest,\n[Sender Name]","personalized_evidence":"DIFC cigar and social signals","evidence_urls":"https://example.com","review_status":"pass","human_decision":"pending","risk_flags":""},
 {"place_id":"demo-003","venue":"Al Maryah Cigar Club","subject":"A shared tea round for Al Maryah Cigar Club","body":"Hello Al Maryah Cigar Club team,\n\nI am [Sender Name] from Dragon Monarch. We produce pressed whole-leaf tea for premium lounges: one brick, one pot, no training required.\n\nWe noticed your events and cigar positioning and are selecting venues in Abu Dhabi for a pilot kit.\n\nWould you like me to send the pilot kit for your team to test? No purchase obligation.\n\nReply unsubscribe to opt out.\n\nBest,\n[Sender Name]","personalized_evidence":"Cigar events and lounge positioning","evidence_urls":"https://example.com","review_status":"needs_review","human_decision":"pending","risk_flags":"needs_human_review"}
]

def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            return list(csv.DictReader(f))
    except Exception:
        return []

def first_existing(paths: list[Path]) -> tuple[list[dict], str, bool]:
    for path in paths:
        rows = read_csv(path)
        if rows:
            return rows, str(path), False
    return DEMO_LEADS, "演示数据", True

def load_leads() -> tuple[list[dict], str, bool]:
    return first_existing([
        DATA_DIR / "qualified.csv",
        DATA_DIR / "free_dubai_leads.csv",
        DATA_DIR / "free_leads.csv",
        DATA_DIR / "enriched.csv",
        DATA_DIR / "sample_scored.csv",
        DATA_DIR / "sample_enriched.csv",
        DATA_DIR / "raw.csv",
        AGENT_ROOT / "sample_leads.csv",
    ])

def load_drafts() -> tuple[list[dict], str, bool]:
    for path in [DATA_DIR / "review_queue.csv", DATA_DIR / "drafts.csv", DATA_DIR / "sample_review_queue.csv", DATA_DIR / "sample_drafts.csv"]:
        rows = read_csv(path)
        if rows:
            return rows, str(path), False
    return DEMO_DRAFTS, "演示数据", True

def num(value, default=0):
    try:
        return float(str(value).replace("%", "").strip())
    except Exception:
        return default

def dashboard_payload() -> dict:
    leads, source, demo = load_leads()
    drafts, draft_source, draft_demo = load_drafts()
    qualified = [row for row in leads if str(row.get("qualified", "")).lower() in ("yes", "true", "1") or num(row.get("icp_score")) >= 65]
    contactable = [row for row in leads if row.get("public_business_email") or row.get("public_business_phone")]
    reviews = [row for row in drafts if str(row.get("human_decision", "pending")).lower() == "pending"]
    approved = [row for row in drafts if str(row.get("human_decision", "")).lower() == "approved" or str(row.get("send_ready", "")).lower() == "yes"]
    sent = [row for row in leads if str(row.get("stage", "")).lower() in ("sent", "已发送", "已寄样", "试摆中", "已回复")]
    city_counts, priority_counts, stage_counts = {}, {"A": 0, "B": 0, "C": 0}, {}
    for row in leads:
        city = row.get("city") or "未知"
        city_counts[city] = city_counts.get(city, 0) + 1
        priority = row.get("priority") or "C"
        priority_counts[priority] = priority_counts.get(priority, 0) + 1
        stage = row.get("stage") or "待处理"
        stage_counts[stage] = stage_counts.get(stage, 0) + 1
    funnel = [
        {"label": "发现门店", "value": len(leads)},
        {"label": "公开联系方式", "value": len(contactable)},
        {"label": "合格客户", "value": len(qualified)},
        {"label": "生成草稿", "value": len(drafts)},
        {"label": "人工批准", "value": len(approved)},
        {"label": "进入推进", "value": len(sent)},
    ]
    return {
        "demo": demo and draft_demo,
        "source": source if not demo else draft_source,
        "metrics": {
            "leads": len(leads), "contactable": len(contactable), "qualified": len(qualified),
            "drafts": len(drafts), "pending_review": len(reviews), "approved": len(approved), "sent": len(sent),
            "contact_rate": round(len(contactable) / max(len(leads), 1) * 100, 1),
            "qualified_rate": round(len(qualified) / max(len(leads), 1) * 100, 1),
        },
        "funnel": funnel,
        "cities": [{"name": k, "value": v} for k, v in sorted(city_counts.items(), key=lambda x: -x[1])],
        "priorities": [{"name": k, "value": v} for k, v in priority_counts.items()],
        "stages": [{"name": k, "value": v} for k, v in sorted(stage_counts.items(), key=lambda x: -x[1])],
        "recent": leads[-8:],
    }

def public_settings() -> dict:
    if not SETTINGS_PATH.exists():
        return {"has_google": False, "has_deepseek": False, "has_openai": False, "deepseek_model": "deepseek-flash", "sender_name": "", "sender_email": "", "sender_phone": ""}
    try:
        s = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except Exception:
        s = {}
    return {
        "has_google": bool(s.get("google_key")), "has_deepseek": bool(s.get("deepseek_key")), "has_openai": bool(s.get("openai_key")),
        "deepseek_model": s.get("deepseek_model", "deepseek-flash"), "openai_model": s.get("openai_model", ""),
        "sender_name": s.get("sender_name", ""), "sender_email": s.get("sender_email", ""), "sender_phone": s.get("sender_phone", ""),
    }

def save_settings(data: dict) -> None:
    existing = {}
    if SETTINGS_PATH.exists():
        try:
            existing = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except Exception:
            existing = {}
    for key in ("google_key", "deepseek_key", "deepseek_model", "openai_key", "openai_model", "sender_name", "sender_email", "sender_phone"):
        if key in data and data[key] is not None:
            existing[key] = str(data[key]).strip()
    SETTINGS_PATH.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")

def run_job(kind: str, payload: dict) -> str:
    job_id = uuid.uuid4().hex[:12]
    with JOBS_LOCK:
        JOBS[job_id] = {"id": job_id, "kind": kind, "status": "queued", "logs": [], "created_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    threading.Thread(target=_job_worker, args=(job_id, kind, payload), daemon=True).start()
    return job_id

def _job_worker(job_id: str, kind: str, payload: dict) -> None:
    with JOBS_LOCK:
        job = JOBS[job_id]
        job["status"] = "running"
    settings = {}
    if SETTINGS_PATH.exists():
        try:
            settings = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except Exception:
            settings = {}
    env = os.environ.copy()
    env["GOOGLE_MAPS_API_KEY"] = settings.get("google_key", env.get("GOOGLE_MAPS_API_KEY", ""))
    env["DEEPSEEK_API_KEY"] = settings.get("deepseek_key", env.get("DEEPSEEK_API_KEY", ""))
    env["DEEPSEEK_MODEL"] = settings.get("deepseek_model", env.get("DEEPSEEK_MODEL", "deepseek-flash"))
    env["OPENAI_API_KEY"] = settings.get("openai_key", env.get("OPENAI_API_KEY", ""))
    env["OPENAI_MODEL"] = settings.get("openai_model", env.get("OPENAI_MODEL", ""))
    if kind == "discover" and payload.get("keyword"):
        region = str(payload.get("region") or "AE").upper()
        country = {"AE": "UAE", "SA": "KSA", "QA": "Qatar"}.get(region, region)
        query = " ".join(x for x in [str(payload.get("keyword", "")).strip(), str(payload.get("type", "")).strip()] if x)
        query_file = DATA_DIR / "web_queries.csv"
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with query_file.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["country", "city", "district", "query"])
            writer.writerow([country, "", "", query])
        payload["queries"] = str(query_file)
    if kind == "discover_free":
        city = str(payload.get("city") or "Dubai")
        country = str(payload.get("country") or ("UAE" if city in ("Dubai", "Abu Dhabi") else "KSA" if city == "Riyadh" else "Qatar"))
        bbox_map = {
            "Dubai": "55.15,25.10,55.40,25.35",
            "Abu Dhabi": "54.25,24.35,54.60,24.60",
            "Riyadh": "46.45,24.55,46.90,24.90",
            "Doha": "51.40,25.18,51.65,25.42",
        }
        bbox = str(payload.get("bbox") or bbox_map.get(city, "55.15,25.10,55.40,25.35"))
        slug = city.lower().replace(" ", "_")
        cache = PROJECT_ROOT / "11_研究交付" / f"overture_{slug}.geojson"
        output = str(payload.get("output") or DATA_DIR / "free_leads.csv")
        cmd = [sys.executable, str(AGENT_ROOT / "overture_leads.py"), "--bbox", bbox, "--cache", str(cache), "--city", city, "--country", country, "--output", output, "--limit", str(payload.get("limit", 100))]
        with JOBS_LOCK:
            job["command"] = " ".join(cmd)
        proc = subprocess.Popen(cmd, cwd=str(AGENT_ROOT), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        assert proc.stdout is not None
        for line in proc.stdout:
            with JOBS_LOCK:
                job["logs"].append(line.rstrip())
        code = proc.wait()
        with JOBS_LOCK:
            job["status"] = "done" if code == 0 else "failed"; job["exit_code"] = code
        return
    defaults = {
        "discover": {"queries": str(AGENT_ROOT / "queries_sample.csv"), "output": str(DATA_DIR / "raw.csv"), "region": "AE"},
        "enrich": {"input": str(DATA_DIR / "raw.csv"), "output": str(DATA_DIR / "enriched.csv")},
        "score": {"input": str(DATA_DIR / "enriched.csv"), "output": str(DATA_DIR / "qualified.csv")},
        "draft": {"input": str(DATA_DIR / "qualified.csv"), "output": str(DATA_DIR / "drafts.csv"), "provider": "template", "limit": 0},
        "review": {"input": str(DATA_DIR / "drafts.csv"), "output": str(DATA_DIR / "review_queue.csv")},
        "approve": {"input": str(DATA_DIR / "review_queue.csv"), "output": str(DATA_DIR / "approved.csv"), "reviewer": "Owner"},
    }
    merged = dict(defaults.get(kind, {}))
    merged.update(payload or {})
    payload = merged
    mapping = {
        "discover": ["discover", "--queries", payload.get("queries", ""), "--output", payload.get("output", ""), "--region", payload.get("region", "AE")],
        "enrich": ["enrich", "--input", payload.get("input", ""), "--output", payload.get("output", "")],
        "score": ["score", "--input", payload.get("input", ""), "--output", payload.get("output", ""), "--qualified-only"],
        "draft": ["draft", "--input", payload.get("input", ""), "--output", payload.get("output", ""), "--provider", payload.get("provider", "template"), "--limit", str(payload.get("limit", 0)), "--language", payload.get("language", "en")],
        "review": ["review", "--input", payload.get("input", ""), "--output", payload.get("output", "")],
    }
    try:
        if kind == "approve":
            cmd = [sys.executable, str(AGENT_ROOT / "approve_drafts.py"), "--input", payload.get("input", ""), "--output", payload.get("output", ""), "--reviewer", payload.get("reviewer", "Owner")]
            for lead_id in payload.get("lead_ids", []):
                cmd += ["--lead-id", str(lead_id)]
        else:
            cmd = [sys.executable, str(PIPELINE)] + mapping[kind]
            if kind == "draft" and payload.get("model"):
                cmd += ["--model", str(payload["model"])]
        with JOBS_LOCK:
            job["command"] = " ".join(cmd)
        proc = subprocess.Popen(cmd, cwd=str(AGENT_ROOT), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        assert proc.stdout is not None
        for line in proc.stdout:
            with JOBS_LOCK:
                job["logs"].append(line.rstrip())
        code = proc.wait()
        with JOBS_LOCK:
            job["status"] = "done" if code == 0 else "failed"
            job["exit_code"] = code
    except Exception as exc:
        with JOBS_LOCK:
            job["status"] = "failed"
            job["logs"].append(str(exc))

def translate_with_deepseek(data: dict) -> dict:
    target_language = data.get("target_language", "en")
    subject_zh = str(data.get("subject_zh", "")).strip()
    body_zh = str(data.get("body_zh", "")).strip()
    if not subject_zh or not body_zh:
        raise ValueError("subject_zh and body_zh are required")
    settings = json.loads(SETTINGS_PATH.read_text(encoding="utf-8")) if SETTINGS_PATH.exists() else {}
    api_key = settings.get("deepseek_key", os.getenv("DEEPSEEK_API_KEY", "")).strip()
    model = settings.get("deepseek_model", "deepseek-flash")
    if not api_key:
        raise ValueError("DEEPSEEK_API_KEY is not set")
    from openai import OpenAI
    client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
    target_name = "Arabic" if target_language == "ar" else "English"
    instructions = (
        f"Translate the following Simplified Chinese B2B outreach email into {target_name}. "
        "Preserve names, URLs and factual details. Do not add new facts or health claims. "
        "Maintain a concise, professional tone and include the unsubscribe wording. "
        "Return only valid JSON with keys: subject, body."
    )
    payload = {"subject_zh": subject_zh, "body_zh": body_zh}
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "system", "content": instructions}, {"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
        response_format={"type": "json_object"},
    )
    result = json.loads(response.choices[0].message.content or "{}")
    return {"subject": str(result.get("subject", "")).strip(), "body": str(result.get("body", "")).strip(), "target_language": target_language}


def upsert_review_draft(data: dict) -> dict:
    path = DATA_DIR / "review_queue.csv"
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    rows = read_csv(path)
    key_value = str(data.get("lead_id") or data.get("place_id") or "").strip()
    if not key_value:
        raise ValueError("lead_id or place_id is required")
    clean = {k: v for k, v in data.items() if k not in {"deepseek_key", "openai_key", "google_key"}}
    clean["lead_id"] = str(clean.get("lead_id") or key_value)
    clean["review_status"] = "needs_review"
    clean["human_decision"] = "pending"
    clean["send_ready"] = "no"
    replaced = False
    for i, row in enumerate(rows):
        row_key = str(row.get("lead_id") or row.get("place_id") or "")
        if row_key == key_value or (row.get("place_id") and row.get("place_id") == clean.get("place_id")):
            rows[i] = {**row, **clean}
            replaced = True
            break
    if not replaced:
        rows.append(clean)
    fields = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    tmp = path.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(rows)
    tmp.replace(path)
    return {"ok": True, "saved": key_value, "path": str(path)}


class Handler(BaseHTTPRequestHandler):
    server_version = "DragonMonarchConsole/1.0"

    def log_message(self, fmt, *args):
        return

    def _send(self, status, body, content_type="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            if path == "/api/dashboard":
                return self._send(200, dashboard_payload())
            if path == "/api/leads":
                rows, source, demo = load_leads()
                q = (parse_qs(parsed.query).get("q", [""])[0] or "").lower()
                if q:
                    rows = [r for r in rows if q in json.dumps(r, ensure_ascii=False).lower()]
                return self._send(200, {"rows": rows, "source": source, "demo": demo})
            if path == "/api/drafts":
                rows, source, demo = load_drafts()
                return self._send(200, {"rows": rows, "source": source, "demo": demo})
            if path == "/api/settings":
                return self._send(200, public_settings())
            if path.startswith("/api/jobs/"):
                job_id = path.rsplit("/", 1)[-1]
                with JOBS_LOCK:
                    job = JOBS.get(job_id)
                return self._send(200 if job else 404, job or {"error": "not_found"})
            if path == "/":
                path = "/index.html"
            file_path = (WEB_ROOT / path.lstrip("/")).resolve()
            if not str(file_path).startswith(str(WEB_ROOT.resolve())) or not file_path.exists() or not file_path.is_file():
                return self._send(404, {"error": "not_found"})
            ctype = {"html": "text/html; charset=utf-8", "css": "text/css; charset=utf-8", "js": "application/javascript; charset=utf-8"}.get(file_path.suffix.lstrip("."), "application/octet-stream")
            return self._send(200, file_path.read_bytes(), ctype)
        except Exception as exc:
            return self._send(500, {"error": str(exc)})

    def do_POST(self):
        try:
            data = self._read_json()
            if self.path == "/api/settings":
                save_settings(data)
                return self._send(200, {"ok": True, "settings": public_settings()})
            if self.path == "/api/translate":
                return self._send(200, translate_with_deepseek(data))
            if self.path == "/api/draft/save":
                return self._send(200, upsert_review_draft(data))
            if self.path == "/api/jobs":
                kind = str(data.get("kind", "")).strip()
                if kind not in {"discover", "discover_free", "enrich", "score", "draft", "review", "approve"}:
                    return self._send(400, {"error": "unsupported_job"})
                payload = data.get("payload") or {}
                job_id = run_job(kind, payload)
                return self._send(202, {"job_id": job_id})
            return self._send(404, {"error": "not_found"})
        except ValueError as exc:
            return self._send(400, {"error": str(exc)})
        except Exception as exc:
            return self._send(500, {"error": str(exc)})

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if not PIPELINE.exists():
        raise SystemExit(f"Pipeline not found: {PIPELINE}")
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Web console: http://{args.host}:{args.port}")
    server.serve_forever()

if __name__ == "__main__":
    main()
